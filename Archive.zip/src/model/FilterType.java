package model;

/**
 * The possible filter types.
 */
public enum FilterType {
  Blur, Sharpen
}
