package model;

/**
 * The possible color transformations.
 */
public enum ColorTransformationType {

  Sepia, Gray
}
